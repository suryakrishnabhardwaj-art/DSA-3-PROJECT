import csv, pathlib
from app.matching import resolve, score_pair


def load():
    p = pathlib.Path(__file__).parents[2] / "data" / "sample_products.csv"
    return [{**r, "price": float(r["price"])} for r in csv.DictReader(open(p))]


def test_same_product_matches():
    a = {"title": "Logitech MX Master 3S Wireless Mouse", "brand": "Logitech", "price": 99}
    b = {"title": "Logitech MX Master 3S Mouse Graphite", "brand": "Logitech", "price": 95}
    assert score_pair(a, b)["score"] >= 0.75


def test_model_conflict_does_not_match():
    a = {"title": "Sony WH-1000XM5 Headphones", "brand": "Sony", "price": 399}
    b = {"title": "Sony WH-1000XM4 Headphones", "brand": "Sony", "price": 279}
    assert score_pair(a, b)["score"] < 0.75


def test_gtin_forces_match():
    a = {"title": "x", "gtin": "123"}
    b = {"title": "totally different", "gtin": "123"}
    assert score_pair(a, b)["score"] == 1.0


def test_sample_clusters():
    clusters = resolve(load())
    assert clusters[0]["size"] >= 2 and len(clusters) < 10
