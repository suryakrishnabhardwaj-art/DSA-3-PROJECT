"""Entity-resolution core: pairwise scoring + clustering of product listings."""
import re
from collections import defaultdict
from itertools import combinations
from rapidfuzz import fuzz

STOPWORDS = {"the", "and", "with", "for", "new", "pack", "of", "a", "in", "by"}
MODEL_RE = re.compile(r"\b(?=[a-z0-9-]*\d)(?=[a-z0-9-]*[a-z])[a-z0-9-]{3,}\b")


def normalize(text: str) -> str:
    text = re.sub(r"[^a-z0-9\- ]+", " ", (text or "").lower())
    return " ".join(w for w in text.split() if w not in STOPWORDS)


def model_tokens(text: str) -> set[str]:
    """Tokens mixing letters and digits (e.g. wh-1000xm5), minus storage sizes like 128gb."""
    toks = {m.replace("-", "") for m in MODEL_RE.findall(normalize(text))}
    return {t for t in toks if not re.fullmatch(r"\d+(gb|tb|mb|mah|hz|mp|g|w)", t)}


COLORS = {"black", "white", "blue", "red", "silver", "gold", "green", "graphite", "grey", "gray", "pink", "purple"}
TIERS = {"pro", "max", "ultra", "plus", "mini", "lite"}


def variant_words(text: str, vocab: set) -> set:
    return set(normalize(text).split()) & vocab


def score_pair(a: dict, b: dict) -> dict:
    """Return a 0-1 match score with the signals that produced it."""
    ga, gb = (a.get("gtin") or "").strip(), (b.get("gtin") or "").strip()
    if ga and ga == gb:
        return {"score": 1.0, "signals": {"gtin": "exact match"}}

    title = fuzz.token_set_ratio(normalize(a["title"]), normalize(b["title"])) / 100
    signals = {"title": round(title, 2)}
    score = title * 0.55

    ba, bb = normalize(a.get("brand", "")), normalize(b.get("brand", ""))
    if ba and bb:
        same = ba == bb
        signals["brand"] = "same" if same else "different"
        score += 0.2 if same else -0.3
    else:
        score += 0.1

    ma, mb = model_tokens(a["title"]), model_tokens(b["title"])
    if ma and mb:
        overlap = bool(ma & mb)
        signals["model"] = "shared" if overlap else "conflict"
        score += 0.2 if overlap else -0.3
    else:
        score += 0.08

    for name, vocab, penalty in (("color", COLORS, 0.2), ("tier", TIERS, 0.25)):
        va, vb = variant_words(a["title"], vocab), variant_words(b["title"], vocab)
        if name == "tier" and (va or vb) and va != vb:
            signals[name] = "conflict"
            score -= penalty
        elif name == "color" and va and vb and not (va & vb):
            signals[name] = "conflict"
            score -= penalty

    pa, pb = a.get("price"), b.get("price")
    if pa and pb:
        close = abs(pa - pb) / max(pa, pb) <= 0.25
        signals["price"] = "close" if close else "far apart"
        score += 0.05 if close else -0.05
    else:
        score += 0.025

    return {"score": round(max(0.0, min(1.0, score)), 3), "signals": signals}


def _blocks(products: list[dict]) -> dict:
    """Cheap candidate generation so we don't compare every pair."""
    idx = defaultdict(list)
    for i, p in enumerate(products):
        if p.get("gtin"):
            idx[("gtin", p["gtin"])].append(i)
        if p.get("brand"):
            idx[("brand", normalize(p["brand"]))].append(i)
        for m in model_tokens(p["title"]):
            idx[("model", m)].append(i)
    return idx


def resolve(products: list[dict], threshold: float = 0.75) -> list[dict]:
    parent = list(range(len(products)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    seen, links = set(), {}
    for ids in _blocks(products).values():
        for i, j in combinations(ids, 2):
            if (i, j) in seen:
                continue
            seen.add((i, j))
            r = score_pair(products[i], products[j])
            if r["score"] >= threshold:
                parent[find(i)] = find(j)
                links[(i, j)] = r

    groups = defaultdict(list)
    for i in range(len(products)):
        groups[find(i)].append(i)

    clusters = []
    for members in groups.values():
        canon = max(members, key=lambda i: len(products[i]["title"]))
        clusters.append({
            "canonical_title": products[canon]["title"],
            "size": len(members),
            "products": [products[i] for i in members],
            "links": [{"a": i, "b": j, **r} for (i, j), r in links.items() if i in members],
        })
    return sorted(clusters, key=lambda c: -c["size"])
