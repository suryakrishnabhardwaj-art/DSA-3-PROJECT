import csv, io
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .matching import resolve, score_pair

app = FastAPI(title="Product Entity-Resolution API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class Product(BaseModel):
    id: str = ""
    title: str
    brand: str = ""
    price: float | None = None
    gtin: str = ""
    source: str = ""


class ResolveRequest(BaseModel):
    products: list[Product]
    threshold: float = 0.75


class PairRequest(BaseModel):
    a: Product
    b: Product


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/match")
def match_pair(req: PairRequest):
    return score_pair(req.a.model_dump(), req.b.model_dump())


@app.post("/api/resolve")
def resolve_products(req: ResolveRequest):
    if len(req.products) > 5000:
        raise HTTPException(413, "Send at most 5000 products per request.")
    clusters = resolve([p.model_dump() for p in req.products], req.threshold)
    return {"total": len(req.products), "clusters": clusters}


@app.post("/api/resolve/csv")
async def resolve_csv(file: UploadFile = File(...), threshold: float = 0.75):
    rows = csv.DictReader(io.StringIO((await file.read()).decode("utf-8-sig")))
    if not rows.fieldnames or "title" not in rows.fieldnames:
        raise HTTPException(400, "CSV needs a 'title' column. Optional: id, brand, price, gtin, source.")
    products = []
    for n, r in enumerate(rows):
        try:
            price = float(r["price"]) if r.get("price") else None
        except ValueError:
            price = None
        products.append({"id": r.get("id") or str(n), "title": r["title"], "brand": r.get("brand", ""),
                         "price": price, "gtin": r.get("gtin", ""), "source": r.get("source", "")})
    if len(products) > 5000:
        raise HTTPException(413, "Send at most 5000 products per request.")
    return {"total": len(products), "clusters": resolve(products, threshold)}
