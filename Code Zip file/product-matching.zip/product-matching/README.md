# E-Commerce Product Entity-Resolution & Matching Platform

Groups product listings from different stores that describe the same item.

**How it matches** (backend/app/matching.py): a barcode (GTIN) match is decisive. Otherwise each pair gets a
score from fuzzy title similarity, brand, model number (e.g. WH-1000XM5), color/edition conflicts and price
proximity. Pairs above the threshold are merged into clusters (union-find). Candidate pairs come from shared
brand, model or barcode, so it avoids comparing every listing with every other.

## Run the backend
    cd backend
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    pytest
    uvicorn app.main:app --reload        # http://localhost:8000/docs

## Run the frontend
    cd frontend
    npm install
    npm run dev                          # http://localhost:5173 (proxies /api to :8000)

Upload `data/sample_products.csv` to try it.

## API
- `POST /api/match` – score two products
- `POST /api/resolve` – JSON list of products → clusters
- `POST /api/resolve/csv` – CSV upload → clusters

## Ideas to extend
Add a database, embedding-based similarity, a human review queue for borderline scores, and learned weights.
