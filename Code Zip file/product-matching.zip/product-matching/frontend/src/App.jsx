import { useState } from "react";

const SIGNAL_LABEL = { title: "Title", brand: "Brand", model: "Model", color: "Color", tier: "Edition", price: "Price", gtin: "Barcode" };

export default function App() {
  const [file, setFile] = useState(null);
  const [threshold, setThreshold] = useState(0.75);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function run() {
    setError("");
    setLoading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      const res = await fetch(`/api/resolve/csv?threshold=${threshold}`, { method: "POST", body });
      if (!res.ok) throw new Error((await res.json()).detail || "Request failed");
      setResult(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  const duplicates = result ? result.total - result.clusters.length : 0;

  return (
    <main>
      <header>
        <h1>Find the same product across stores</h1>
        <p>Upload a product list. Listings that describe the same item are grouped, with the reasons shown.</p>
      </header>

      <section className="controls">
        <label className="file">
          <input type="file" accept=".csv" onChange={(e) => setFile(e.target.files[0])} />
          <span>{file ? file.name : "Choose a CSV file"}</span>
        </label>
        <label className="slider">
          Match strictness: {Math.round(threshold * 100)}%
          <input type="range" min="0.5" max="0.95" step="0.01" value={threshold} onChange={(e) => setThreshold(+e.target.value)} />
        </label>
        <button onClick={run} disabled={!file || loading}>{loading ? "Matching…" : "Match products"}</button>
      </section>
      <p className="hint">Columns: title (required), id, brand, price, gtin, source.</p>

      {error && <p role="alert" className="error">{error}</p>}

      {result && (
        <>
          <p className="summary">
            {result.total} listings became <strong>{result.clusters.length}</strong> products. {duplicates} duplicates merged.
          </p>
          <ul className="clusters">
            {result.clusters.map((c, i) => (
              <li key={i} className={c.size > 1 ? "merged" : ""}>
                <h2>{c.canonical_title}</h2>
                <p className="count">{c.size > 1 ? `${c.size} listings matched` : "No match found"}</p>
                <table>
                  <tbody>
                    {c.products.map((p, k) => (
                      <tr key={k}>
                        <td>{p.source || "—"}</td>
                        <td>{p.title}</td>
                        <td className="num">{p.price != null ? `$${p.price}` : ""}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {c.links[0] && (
                  <p className="why">
                    Why: {Object.entries(c.links[0].signals).map(([k, v]) => `${SIGNAL_LABEL[k] || k} ${v}`).join(", ")}
                  </p>
                )}
              </li>
            ))}
          </ul>
        </>
      )}
    </main>
  );
}
